package com.orm;

public class Tgongwen
{
	private String id;
	private String wenhao;
	private String bumen;
	private String title;
	
	private String fujian;
	private String beizhu;
	private String tianjiashi;
	private String tai;
	
	private String yijian;
	private String shenheshi;
	private String fujianswfpath;
	
	public String getBeizhu()
	{
		return beizhu;
	}
	public void setBeizhu(String beizhu)
	{
		this.beizhu = beizhu;
	}
	public String getBumen()
	{
		return bumen;
	}
	public void setBumen(String bumen)
	{
		this.bumen = bumen;
	}
	public String getFujian()
	{
		return fujian;
	}
	public String getYijian()
	{
		return yijian;
	}
	public void setYijian(String yijian)
	{
		this.yijian = yijian;
	}
	public void setFujian(String fujian)
	{
		this.fujian = fujian;
	}
	public String getId()
	{
		return id;
	}
	public void setId(String id)
	{
		this.id = id;
	}
	public String getShenheshi()
	{
		return shenheshi;
	}
	public void setShenheshi(String shenheshi)
	{
		this.shenheshi = shenheshi;
	}
	public String getTai()
	{
		return tai;
	}
	public void setTai(String tai)
	{
		this.tai = tai;
	}
	public String getTianjiashi()
	{
		return tianjiashi;
	}
	public void setTianjiashi(String tianjiashi)
	{
		this.tianjiashi = tianjiashi;
	}
	public String getTitle()
	{
		return title;
	}
	public void setTitle(String title)
	{
		this.title = title;
	}
	public String getWenhao()
	{
		return wenhao;
	}
	public void setWenhao(String wenhao)
	{
		this.wenhao = wenhao;
	}
	public String getFujianswfpath() {
		return fujianswfpath;
	}
	public void setFujianswfpath(String fujianswf) {
		this.fujianswfpath = fujianswf;
	}
	
}
